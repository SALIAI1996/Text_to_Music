import logging
import json
import os
import uuid
from datetime import datetime
from flask import Blueprint, request, render_template, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from app import db
from models import User, Transaction, Withdrawal

# Configure logger
logger = logging.getLogger(__name__)

# Create payments blueprint
payments_bp = Blueprint('payments', __name__, url_prefix='/payments')

# Mock Razorpay API Key (in production, get from environment variables)
RAZORPAY_KEY_ID = os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_key')
RAZORPAY_KEY_SECRET = os.environ.get('RAZORPAY_KEY_SECRET', 'rzp_test_secret')

@payments_bp.route('/wallet')
@login_required
def wallet():
    # Get user's transaction history
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    
    # Get user's withdrawal history
    withdrawals = Withdrawal.query.filter_by(user_id=current_user.id).order_by(Withdrawal.created_at.desc()).all()
    
    return render_template('wallet.html', 
                          transactions=transactions, 
                          withdrawals=withdrawals,
                          razorpay_key_id=RAZORPAY_KEY_ID)

@payments_bp.route('/add_money', methods=['GET', 'POST'])
@login_required
def add_money():
    if request.method == 'POST':
        amount = float(request.form.get('amount', 0))
        
        if amount <= 0:
            flash('Please enter a valid amount', 'danger')
            return redirect(url_for('payments.wallet'))
        
        # Generate a unique order ID
        order_id = f"order_{uuid.uuid4().hex}"
        
        # In a real app, create an order with Razorpay API
        # Here we're just simulating the process
        order_data = {
            'id': order_id,
            'amount': int(amount * 100),  # Amount in paise
            'currency': 'INR',
            'receipt': f"receipt_{uuid.uuid4().hex}"
        }
        
        return render_template('payment_confirmation.html', 
                              amount=amount,
                              order_data=order_data,
                              razorpay_key_id=RAZORPAY_KEY_ID)
    
    return render_template('add_money.html')

@payments_bp.route('/verify_payment', methods=['POST'])
@login_required
def verify_payment():
    try:
        # Get payment data
        payment_id = request.form.get('razorpay_payment_id')
        order_id = request.form.get('razorpay_order_id')
        signature = request.form.get('razorpay_signature')
        amount = float(request.form.get('amount', 0))
        
        # In a real app, verify the payment with Razorpay API
        # Here we're just simulating a successful payment
        
        # Add amount to user's wallet
        current_user.add_to_wallet(amount)
        
        # Record transaction
        transaction = Transaction(
            user_id=current_user.id,
            amount=amount,
            transaction_type='deposit',
            payment_id=payment_id,
            status='completed'
        )
        db.session.add(transaction)
        db.session.commit()
        
        flash(f'₹{amount} added to your wallet successfully!', 'success')
        return redirect(url_for('payments.wallet'))
    
    except Exception as e:
        logger.error(f"Payment verification error: {str(e)}")
        flash('Payment verification failed. Please try again or contact support.', 'danger')
        return redirect(url_for('payments.wallet'))

@payments_bp.route('/withdraw', methods=['GET', 'POST'])
@login_required
def withdraw():
    if request.method == 'POST':
        amount = float(request.form.get('amount', 0))
        upi_id = request.form.get('upi_id')
        
        # Validate amount
        if amount <= 0:
            flash('Please enter a valid amount', 'danger')
            return render_template('withdraw.html')
        
        # Check minimum withdrawal amount
        if amount < 10:
            flash('Minimum withdrawal amount is ₹10', 'danger')
            return render_template('withdraw.html')
        
        # Check if user has enough balance
        if current_user.wallet_balance < amount:
            flash('Insufficient balance', 'danger')
            return render_template('withdraw.html')
        
        # Validate UPI ID (basic validation)
        if not upi_id or '@' not in upi_id:
            flash('Please enter a valid UPI ID', 'danger')
            return render_template('withdraw.html')
        
        try:
            # Deduct amount from user's wallet
            if not current_user.deduct_from_wallet(amount):
                flash('Withdrawal failed. Please try again.', 'danger')
                return render_template('withdraw.html')
            
            # Create withdrawal record
            withdrawal = Withdrawal(
                user_id=current_user.id,
                amount=amount,
                upi_id=upi_id,
                status='pending'
            )
            db.session.add(withdrawal)
            
            # Record transaction
            transaction = Transaction(
                user_id=current_user.id,
                amount=amount,
                transaction_type='withdrawal',
                status='pending'
            )
            db.session.add(transaction)
            
            db.session.commit()
            
            flash('Withdrawal request submitted successfully. It will be processed within 24-48 hours.', 'success')
            return redirect(url_for('payments.wallet'))
        
        except Exception as e:
            logger.error(f"Withdrawal error: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('withdraw.html')

@payments_bp.route('/transactions')
@login_required
def transactions():
    # Get all user's transactions
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).all()
    return render_template('transactions.html', transactions=transactions)

@payments_bp.route('/withdrawals')
@login_required
def withdrawals():
    # Get all user's withdrawals
    withdrawals = Withdrawal.query.filter_by(user_id=current_user.id).order_by(Withdrawal.created_at.desc()).all()
    return render_template('withdrawals.html', withdrawals=withdrawals)

# API endpoints for payment hooks (in a real app, would be secured with proper authentication)
@payments_bp.route('/webhook', methods=['POST'])
def payment_webhook():
    # This would process webhooks from Razorpay
    try:
        webhook_data = request.json
        event_type = webhook_data.get('event')
        
        logger.info(f"Received webhook: {event_type}")
        
        # Process different event types
        if event_type == 'payment.captured':
            payment_id = webhook_data.get('payload', {}).get('payment', {}).get('entity', {}).get('id')
            amount = webhook_data.get('payload', {}).get('payment', {}).get('entity', {}).get('amount', 0) / 100
            
            # Update transaction status
            transaction = Transaction.query.filter_by(payment_id=payment_id).first()
            if transaction:
                transaction.status = 'completed'
                db.session.commit()
        
        return jsonify({"status": "success"})
    
    except Exception as e:
        logger.error(f"Webhook processing error: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500
