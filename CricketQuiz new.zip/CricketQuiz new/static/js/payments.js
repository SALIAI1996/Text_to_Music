/**
 * Cricket Quiz App - Payments JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
  // Payment elements
  const addMoneyForm = document.getElementById('add-money-form');
  const razorpayPaymentButton = document.getElementById('razorpay-payment-button');
  const withdrawalForm = document.getElementById('withdrawal-form');
  const amountInput = document.getElementById('amount-input');
  const upiIdInput = document.getElementById('upi-id-input');
  
  // Initialize Razorpay payment button if it exists
  if (razorpayPaymentButton) {
    razorpayPaymentButton.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Get order data from data attributes
      const orderData = {
        id: razorpayPaymentButton.getAttribute('data-order-id'),
        amount: razorpayPaymentButton.getAttribute('data-amount'),
        currency: razorpayPaymentButton.getAttribute('data-currency') || 'INR',
        name: 'Cricket Quiz',
        description: 'Add money to wallet',
        key: razorpayPaymentButton.getAttribute('data-key')
      };
      
      // Initialize Razorpay
      const options = {
        key: orderData.key,
        amount: orderData.amount,
        currency: orderData.currency,
        name: orderData.name,
        description: orderData.description,
        order_id: orderData.id,
        handler: function(response) {
          // Handle successful payment
          document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
          document.getElementById('razorpay_order_id').value = response.razorpay_order_id;
          document.getElementById('razorpay_signature').value = response.razorpay_signature;
          
          // Submit the form
          document.getElementById('payment-verification-form').submit();
        },
        prefill: {
          name: document.getElementById('user-name')?.value || '',
          email: document.getElementById('user-email')?.value || '',
          contact: document.getElementById('user-phone')?.value || ''
        },
        theme: {
          color: '#1e88e5'
        }
      };
      
      const rzp = new Razorpay(options);
      rzp.open();
    });
  }
  
  // Validate add money form
  if (addMoneyForm) {
    addMoneyForm.addEventListener('submit', function(e) {
      const amount = parseFloat(document.getElementById('amount').value);
      
      if (isNaN(amount) || amount <= 0) {
        e.preventDefault();
        alert('Please enter a valid amount');
        return false;
      }
      
      if (amount < 10) {
        e.preventDefault();
        alert('Minimum amount is ₹10');
        return false;
      }
      
      if (amount > 10000) {
        e.preventDefault();
        alert('Maximum amount is ₹10,000');
        return false;
      }
      
      // Show loading
      window.appHelpers.showLoading();
    });
  }
  
  // Validate withdrawal form
  if (withdrawalForm) {
    withdrawalForm.addEventListener('submit', function(e) {
      const amount = parseFloat(amountInput.value);
      const upiId = upiIdInput.value;
      
      // Validate amount
      if (isNaN(amount) || amount <= 0) {
        e.preventDefault();
        alert('Please enter a valid amount');
        return false;
      }
      
      if (amount < 10) {
        e.preventDefault();
        alert('Minimum withdrawal amount is ₹10');
        return false;
      }
      
      const maxAmount = parseFloat(amountInput.getAttribute('max') || '10000');
      if (amount > maxAmount) {
        e.preventDefault();
        alert(`Maximum withdrawal amount is ₹${maxAmount}`);
        return false;
      }
      
      // Validate UPI ID
      if (!upiId || !validateUpiId(upiId)) {
        e.preventDefault();
        alert('Please enter a valid UPI ID (e.g., name@upi)');
        return false;
      }
      
      // Show loading
      window.appHelpers.showLoading();
    });
  }
  
  // Format amount input as currency
  if (amountInput) {
    amountInput.addEventListener('input', function() {
      const value = this.value.replace(/[^\d.]/g, ''); // Remove non-numeric characters except decimal point
      
      if (value) {
        // Format as currency (without currency symbol)
        const formattedValue = parseFloat(value).toLocaleString('en-IN', {
          maximumFractionDigits: 2,
          minimumFractionDigits: 0
        });
        
        // Only update if the value actually changed to avoid cursor jumping
        if (formattedValue !== this.value) {
          this.value = formattedValue;
        }
      }
    });
  }
  
  // Validate UPI ID format
  function validateUpiId(upiId) {
    // Basic validation: username@provider
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+$/;
    return regex.test(upiId);
  }
  
  // Transaction history filter
  const transactionFilterSelect = document.getElementById('transaction-filter');
  if (transactionFilterSelect) {
    transactionFilterSelect.addEventListener('change', function() {
      const filterValue = this.value;
      const transactionItems = document.querySelectorAll('.transaction-item');
      
      transactionItems.forEach(item => {
        if (filterValue === 'all' || item.getAttribute('data-type') === filterValue) {
          item.style.display = 'flex';
        } else {
          item.style.display = 'none';
        }
      });
    });
  }
  
  // Update remaining balance in real-time on withdrawal form
  if (amountInput && document.getElementById('remaining-balance')) {
    const walletBalance = parseFloat(document.getElementById('wallet-balance').textContent);
    
    amountInput.addEventListener('input', function() {
      const amount = parseFloat(this.value.replace(/[^\d.]/g, '')) || 0;
      const remainingBalance = Math.max(0, walletBalance - amount);
      
      document.getElementById('remaining-balance').textContent = 
        window.appHelpers.formatCurrency(remainingBalance);
      
      // Update UI based on whether amount is valid
      if (amount > walletBalance) {
        document.getElementById('remaining-balance').classList.add('text-danger');
        document.getElementById('withdrawal-submit-btn').disabled = true;
      } else {
        document.getElementById('remaining-balance').classList.remove('text-danger');
        document.getElementById('withdrawal-submit-btn').disabled = false;
      }
    });
  }
  
  // Copy UPI ID to clipboard
  const copyUpiButtons = document.querySelectorAll('.copy-upi-btn');
  if (copyUpiButtons.length > 0) {
    copyUpiButtons.forEach(button => {
      button.addEventListener('click', function() {
        const upiId = this.getAttribute('data-upi');
        
        navigator.clipboard.writeText(upiId).then(() => {
          // Change button text temporarily
          const originalText = this.textContent;
          this.textContent = 'Copied!';
          
          setTimeout(() => {
            this.textContent = originalText;
          }, 2000);
        }).catch(err => {
          console.error('Failed to copy UPI ID: ', err);
          alert('Failed to copy UPI ID. Please try again.');
        });
      });
    });
  }
});
