/**
 * Cricket Quiz App - Main JavaScript
 */

// DOM Elements
const userMenuToggle = document.querySelector('.user-menu-toggle');
const userMenuDropdown = document.querySelector('.user-menu-dropdown');
const menuToggle = document.querySelector('.menu-toggle');
const navbar = document.querySelector('.navbar-nav');

// Toggle user menu dropdown
if (userMenuToggle && userMenuDropdown) {
  userMenuToggle.addEventListener('click', (e) => {
    e.stopPropagation();
    userMenuDropdown.classList.toggle('show');
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (userMenuDropdown.classList.contains('show')) {
      userMenuDropdown.classList.remove('show');
    }
  });
}

// Mobile menu toggle
if (menuToggle && navbar) {
  menuToggle.addEventListener('click', () => {
    navbar.classList.toggle('active');
  });
}

// Flash messages auto-dismiss
const flashMessages = document.querySelectorAll('.alert');
if (flashMessages.length > 0) {
  flashMessages.forEach(message => {
    setTimeout(() => {
      message.style.opacity = '0';
      setTimeout(() => {
        message.remove();
      }, 500);
    }, 5000);
  });
}

// Modal functionality
function initializeModals() {
  const modalTriggers = document.querySelectorAll('[data-modal-target]');
  const modalCloseButtons = document.querySelectorAll('[data-modal-close]');
  const modalOverlays = document.querySelectorAll('.modal-overlay');

  // Open modal
  modalTriggers.forEach(trigger => {
    trigger.addEventListener('click', () => {
      const modalId = trigger.getAttribute('data-modal-target');
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.classList.add('active');
      }
    });
  });

  // Close modal with close button
  modalCloseButtons.forEach(button => {
    button.addEventListener('click', () => {
      const modal = button.closest('.modal-overlay');
      if (modal) {
        modal.classList.remove('active');
      }
    });
  });

  // Close modal when clicking on overlay
  modalOverlays.forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('active');
      }
    });
  });
}

// Initialize modals if they exist
document.addEventListener('DOMContentLoaded', () => {
  initializeModals();
});

// Form validation
function validateForm(form) {
  let isValid = true;
  const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
  
  inputs.forEach(input => {
    if (!input.value.trim()) {
      isValid = false;
      input.classList.add('is-invalid');
      
      // Add error message if not exists
      let errorMessage = input.nextElementSibling;
      if (!errorMessage || !errorMessage.classList.contains('error-message')) {
        errorMessage = document.createElement('div');
        errorMessage.classList.add('error-message');
        errorMessage.style.color = 'var(--danger-color)';
        errorMessage.style.fontSize = '0.85rem';
        errorMessage.style.marginTop = '5px';
        errorMessage.textContent = 'This field is required';
        input.parentNode.insertBefore(errorMessage, input.nextSibling);
      }
    } else {
      input.classList.remove('is-invalid');
      
      // Remove error message if exists
      const errorMessage = input.nextElementSibling;
      if (errorMessage && errorMessage.classList.contains('error-message')) {
        errorMessage.remove();
      }
    }
  });
  
  return isValid;
}

// Set up form validation for all forms with the 'needs-validation' class
const forms = document.querySelectorAll('form.needs-validation');
forms.forEach(form => {
  form.addEventListener('submit', (e) => {
    if (!validateForm(form)) {
      e.preventDefault();
      e.stopPropagation();
    }
  });
});

// Format currency (Indian Rupees)
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2
  }).format(amount);
}

// Format date and time
function formatDateTime(dateString) {
  const date = new Date(dateString);
  return date.toLocaleString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Helper function to check if an element is in viewport
function isInViewport(element) {
  const rect = element.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

// Animate elements when they come into view
function animateOnScroll() {
  const animatedElements = document.querySelectorAll('.animate-on-scroll');
  
  animatedElements.forEach(element => {
    if (isInViewport(element)) {
      element.classList.add('animated');
    }
  });
}

// Initialize animation on scroll
window.addEventListener('scroll', animateOnScroll);
document.addEventListener('DOMContentLoaded', animateOnScroll);

// Loading overlay
function showLoading() {
  const overlay = document.createElement('div');
  overlay.classList.add('loading-overlay');
  
  const spinner = document.createElement('div');
  spinner.classList.add('loading');
  spinner.innerHTML = '<div></div><div></div><div></div>';
  
  overlay.appendChild(spinner);
  document.body.appendChild(overlay);
}

function hideLoading() {
  const overlay = document.querySelector('.loading-overlay');
  if (overlay) {
    overlay.remove();
  }
}

// Countdown timer function
function startCountdown(element, seconds, onComplete) {
  if (!element) return;
  
  let timeLeft = seconds;
  
  element.textContent = formatTime(timeLeft);
  
  const timer = setInterval(() => {
    timeLeft--;
    
    if (timeLeft <= 0) {
      clearInterval(timer);
      if (typeof onComplete === 'function') {
        onComplete();
      }
    }
    
    element.textContent = formatTime(timeLeft);
    
    // Add warning class when time is running out
    if (timeLeft <= 10) {
      element.classList.add('warning');
    }
  }, 1000);
  
  return timer;
}

// Format time as MM:SS
function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Export functions for use in other scripts
window.appHelpers = {
  formatCurrency,
  formatDateTime,
  startCountdown,
  formatTime,
  showLoading,
  hideLoading,
  validateForm
};
