/**
 * Cricket Quiz App - Admin Dashboard JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
  // Admin dashboard elements
  const deleteButtons = document.querySelectorAll('.delete-btn');
  const processWithdrawalButtons = document.querySelectorAll('.process-withdrawal-btn');
  const dateTimeInputs = document.querySelectorAll('input[type="datetime-local"]');
  const statsChartCanvas = document.getElementById('stats-chart');
  
  // Initialize delete confirmation dialogs
  if (deleteButtons.length > 0) {
    deleteButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
          e.preventDefault();
        }
      });
    });
  }
  
  // Initialize withdrawal processing buttons
  if (processWithdrawalButtons.length > 0) {
    processWithdrawalButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        if (!confirm('Are you sure you want to process this withdrawal?')) {
          e.preventDefault();
        } else {
          // Show loading
          window.appHelpers.showLoading();
          
          // Remove the loading state after form submission
          setTimeout(() => {
            window.appHelpers.hideLoading();
          }, 2000);
        }
      });
    });
  }
  
  // Set default date-time values for new forms
  if (dateTimeInputs.length > 0) {
    dateTimeInputs.forEach(input => {
      if (!input.value) {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        input.value = now.toISOString().slice(0, 16);
      }
    });
  }
  
  // Initialize stats chart if it exists
  if (statsChartCanvas) {
    initializeStatsChart();
  }
  
  /**
   * Initialize statistics chart
   */
  function initializeStatsChart() {
    // Get data from data attributes or API
    const chartDataElement = document.getElementById('chart-data');
    let chartData = {
      labels: ['Quiz Entries', 'Rewards Paid', 'Admin Earnings'],
      values: [0, 0, 0]
    };
    
    if (chartDataElement) {
      try {
        chartData = JSON.parse(chartDataElement.textContent);
      } catch (e) {
        console.error('Error parsing chart data:', e);
      }
    }
    
    // Create chart
    const ctx = statsChartCanvas.getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: chartData.labels,
        datasets: [{
          label: 'Amount (₹)',
          data: chartData.values,
          backgroundColor: [
            'rgba(30, 136, 229, 0.7)',
            'rgba(67, 160, 71, 0.7)',
            'rgba(255, 152, 0, 0.7)'
          ],
          borderColor: [
            'rgba(30, 136, 229, 1)',
            'rgba(67, 160, 71, 1)',
            'rgba(255, 152, 0, 1)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                return '₹' + value;
              }
            }
          }
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: function(context) {
                return '₹' + context.raw;
              }
            }
          }
        }
      }
    });
  }
  
  // Question form validation
  const questionForm = document.getElementById('question-form');
  if (questionForm) {
    questionForm.addEventListener('submit', function(e) {
      const correctOption = document.querySelector('input[name="correct_option"]:checked');
      
      if (!correctOption) {
        e.preventDefault();
        alert('Please select the correct option for this question.');
      }
    });
  }
  
  // Dynamic form fields for quiz questions
  const addOptionButton = document.getElementById('add-option-btn');
  const optionsContainer = document.getElementById('options-container');
  
  if (addOptionButton && optionsContainer) {
    addOptionButton.addEventListener('click', function() {
      const optionCount = optionsContainer.children.length;
      
      if (optionCount < 4) {
        const optionLetter = String.fromCharCode(97 + optionCount); // a, b, c, d
        
        const optionDiv = document.createElement('div');
        optionDiv.className = 'form-group';
        optionDiv.innerHTML = `
          <label class="form-label">Option ${optionLetter.toUpperCase()}</label>
          <div class="d-flex">
            <input type="text" name="option_${optionLetter}" class="form-control" required>
            <div class="form-check ms-3">
              <input class="form-check-input" type="radio" name="correct_option" value="${optionLetter}" id="correct_${optionLetter}">
              <label class="form-check-label" for="correct_${optionLetter}">Correct</label>
            </div>
          </div>
        `;
        
        optionsContainer.appendChild(optionDiv);
        
        // Disable add button if reached max options
        if (optionsContainer.children.length >= 4) {
          addOptionButton.disabled = true;
        }
      }
    });
  }
  
  // Initialize datatables if they exist
  if (typeof $.fn.DataTable !== 'undefined') {
    $('.data-table').DataTable({
      responsive: true,
      order: [[0, 'desc']]
    });
  }
  
  // Process results button
  const processResultsButton = document.querySelector('.process-results-btn');
  if (processResultsButton) {
    processResultsButton.addEventListener('click', function(e) {
      e.preventDefault();
      
      if (!confirm('Are you sure you want to process the results for this quiz?')) {
        return;
      }
      
      const quizId = this.getAttribute('data-quiz-id');
      
      // Show loading
      window.appHelpers.showLoading();
      
      // Call the process results API
      fetch(`/quiz/process_results/${quizId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Key': 'secret_admin_key', // In a real app, this would be a secure token
          'X-CSRFToken': getCSRFToken()
        }
      })
      .then(response => {
        if (!response.ok) {
          return response.json().then(data => {
            throw new Error(data.error || 'Failed to process results');
          });
        }
        return response.json();
      })
      .then(data => {
        window.appHelpers.hideLoading();
        alert(`Results processed successfully! ${data.winners_count} winner(s) with ${window.appHelpers.formatCurrency(data.reward_per_winner)} per winner.`);
        window.location.reload();
      })
      .catch(error => {
        console.error('Error processing results:', error);
        window.appHelpers.hideLoading();
        alert(`Error: ${error.message}`);
      });
    });
  }
  
  /**
   * Get CSRF token from cookie
   */
  function getCSRFToken() {
    const name = 'csrf_token=';
    const decodedCookie = decodeURIComponent(document.cookie);
    const cookieArray = decodedCookie.split(';');
    
    for (let i = 0; i < cookieArray.length; i++) {
      let cookie = cookieArray[i].trim();
      if (cookie.indexOf(name) === 0) {
        return cookie.substring(name.length, cookie.length);
      }
    }
    
    return '';
  }
});
