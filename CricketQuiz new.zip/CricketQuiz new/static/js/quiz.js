/**
 * Cricket Quiz App - Quiz Page JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
  // Quiz elements
  const quizContainer = document.querySelector('.quiz-container');
  const timerElement = document.querySelector('.quiz-timer');
  const questionContainers = document.querySelectorAll('.question-container');
  const navigationButtons = document.querySelectorAll('.quiz-navigation button');
  const submitQuizButton = document.getElementById('submit-quiz');
  
  // Quiz state
  let currentQuestionIndex = 0;
  let answers = [];
  let timers = {};
  let startTimes = {};
  
  // Initialize quiz if the quiz container exists
  if (quizContainer) {
    initializeQuiz();
  }
  
  /**
   * Initialize the quiz
   */
  function initializeQuiz() {
    // Hide all questions except the first one
    questionContainers.forEach((container, index) => {
      if (index !== 0) {
        container.style.display = 'none';
      }
    });
    
    // Setup navigation buttons
    if (navigationButtons.length > 0) {
      navigationButtons.forEach(button => {
        button.addEventListener('click', handleNavigation);
      });
    }
    
    // Setup submit button
    if (submitQuizButton) {
      submitQuizButton.addEventListener('click', handleQuizSubmission);
    }
    
    // Initialize the first question timer
    if (questionContainers.length > 0) {
      startQuestionTimer(currentQuestionIndex);
    }
    
    // Setup option selection
    setupOptionSelection();
  }
  
  /**
   * Set up event listeners for option selection
   */
  function setupOptionSelection() {
    const optionInputs = document.querySelectorAll('.option-item input[type="radio"]');
    
    optionInputs.forEach(input => {
      input.addEventListener('change', (e) => {
        const questionId = e.target.getAttribute('name').replace('question_', '');
        const selectedOption = e.target.value;
        
        // Save answer
        saveAnswer(questionId, selectedOption);
        
        // Auto-navigate to next question after selection
        const currentQuestionContainer = e.target.closest('.question-container');
        const questionIndex = Array.from(questionContainers).indexOf(currentQuestionContainer);
        
        // If this is not the last question, move to the next one after a short delay
        if (questionIndex < questionContainers.length - 1) {
          setTimeout(() => {
            navigateToQuestion(questionIndex + 1);
          }, 500);
        }
      });
    });
  }
  
  /**
   * Handle navigation button clicks
   */
  function handleNavigation(e) {
    const direction = e.target.getAttribute('data-direction');
    
    if (direction === 'next' && currentQuestionIndex < questionContainers.length - 1) {
      navigateToQuestion(currentQuestionIndex + 1);
    } else if (direction === 'prev' && currentQuestionIndex > 0) {
      navigateToQuestion(currentQuestionIndex - 1);
    }
  }
  
  /**
   * Navigate to a specific question
   */
  function navigateToQuestion(index) {
    // Hide current question
    questionContainers[currentQuestionIndex].style.display = 'none';
    
    // Show new question
    questionContainers[index].style.display = 'block';
    
    // Update current index
    currentQuestionIndex = index;
    
    // Update navigation buttons
    updateNavigationButtons();
    
    // Start timer for this question if not already started
    startQuestionTimer(index);
  }
  
  /**
   * Update the navigation buttons based on current question
   */
  function updateNavigationButtons() {
    // Update previous button
    const prevButton = document.querySelector('[data-direction="prev"]');
    if (prevButton) {
      prevButton.disabled = currentQuestionIndex === 0;
    }
    
    // Update next button
    const nextButton = document.querySelector('[data-direction="next"]');
    if (nextButton) {
      const isLastQuestion = currentQuestionIndex === questionContainers.length - 1;
      nextButton.disabled = isLastQuestion;
      
      // Show submit button on last question
      if (submitQuizButton) {
        submitQuizButton.style.display = isLastQuestion ? 'block' : 'none';
      }
    }
  }
  
  /**
   * Start the timer for a specific question
   */
  function startQuestionTimer(index) {
    if (timers[index]) return; // Timer already started
    
    const questionElement = questionContainers[index];
    const questionId = questionElement.getAttribute('data-question-id');
    const timeLimit = parseInt(questionElement.getAttribute('data-time-limit') || '30');
    
    // Record start time
    startTimes[questionId] = new Date().getTime();
    
    // Start countdown
    const timer = window.appHelpers.startCountdown(timerElement, timeLimit, () => {
      // Time's up for this question
      // If no answer was selected, select none and move to next question
      if (!hasAnsweredCurrentQuestion()) {
        saveAnswer(questionId, '');
        
        // Move to next question if not the last one
        if (currentQuestionIndex < questionContainers.length - 1) {
          navigateToQuestion(currentQuestionIndex + 1);
        } else {
          // If it's the last question, enable submit button
          if (submitQuizButton) {
            submitQuizButton.disabled = false;
          }
        }
      }
    });
    
    timers[index] = timer;
  }
  
  /**
   * Check if current question has been answered
   */
  function hasAnsweredCurrentQuestion() {
    const questionElement = questionContainers[currentQuestionIndex];
    const questionId = questionElement.getAttribute('data-question-id');
    
    return answers.some(answer => answer.question_id === questionId);
  }
  
  /**
   * Save an answer
   */
  function saveAnswer(questionId, selectedOption) {
    // Calculate time taken
    const startTime = startTimes[questionId] || new Date().getTime();
    const endTime = new Date().getTime();
    const timeTaken = (endTime - startTime) / 1000; // in seconds
    
    // Check if already answered this question
    const existingAnswerIndex = answers.findIndex(a => a.question_id === questionId);
    
    if (existingAnswerIndex !== -1) {
      // Update existing answer
      answers[existingAnswerIndex] = {
        question_id: questionId,
        answer: selectedOption,
        time_taken: timeTaken
      };
    } else {
      // Add new answer
      answers.push({
        question_id: questionId,
        answer: selectedOption,
        time_taken: timeTaken
      });
    }
  }
  
  /**
   * Handle quiz submission
   */
  function handleQuizSubmission() {
    // Make sure all questions are answered
    const unansweredQuestions = [];
    
    questionContainers.forEach((container, index) => {
      const questionId = container.getAttribute('data-question-id');
      if (!answers.some(a => a.question_id === questionId)) {
        unansweredQuestions.push(index + 1);
      }
    });
    
    if (unansweredQuestions.length > 0) {
      if (!confirm(`You haven't answered question(s) ${unansweredQuestions.join(', ')}. Do you want to submit anyway?`)) {
        return;
      }
      
      // Add empty answers for unanswered questions
      questionContainers.forEach((container) => {
        const questionId = container.getAttribute('data-question-id');
        if (!answers.some(a => a.question_id === questionId)) {
          saveAnswer(questionId, '');
        }
      });
    }
    
    // Show loading overlay
    window.appHelpers.showLoading();
    
    // Submit answers
    const quizId = quizContainer.getAttribute('data-quiz-id');
    submitAnswers(quizId, answers);
  }
  
  /**
   * Submit answers to the server
   */
  function submitAnswers(quizId, answers) {
    fetch(`/quiz/submit/${quizId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': getCSRFToken()
      },
      body: JSON.stringify({ answers })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to submit quiz');
      }
      return response.json();
    })
    .then(data => {
      // Hide loading overlay
      window.appHelpers.hideLoading();
      
      // Redirect to results page
      window.location.href = `/quiz/results/${quizId}`;
    })
    .catch(error => {
      console.error('Error submitting quiz:', error);
      window.appHelpers.hideLoading();
      alert('Failed to submit quiz. Please try again.');
    });
  }
  
  /**
   * Get CSRF token from cookie
   */
  function getCSRFToken() {
    const name = 'csrf_token=';
    const decodedCookie = decodeURIComponent(document.cookie);
    const cookieArray = decodedCookie.split(';');
    
    for (let i = 0; i < cookieArray.length; i++) {
      let cookie = cookieArray[i].trim();
      if (cookie.indexOf(name) === 0) {
        return cookie.substring(name.length, cookie.length);
      }
    }
    
    return '';
  }
});
