import logging
from datetime import datetime, timedelta
from flask import Blueprint, request, render_template, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from sqlalchemy import desc
from app import db
from models import User, Match, Quiz, Question, UserQuiz, Transaction, Withdrawal

# Configure logger
logger = logging.getLogger(__name__)

# Create admin blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Admin required decorator
def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You do not have permission to access this page', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return login_required(decorated_function)

@admin_bp.route('/')
@admin_required
def dashboard():
    # Get counts for dashboard
    users_count = User.query.count()
    matches_count = Match.query.count()
    quizzes_count = Quiz.query.count()
    questions_count = Question.query.count()
    
    # Get total entry fees collected
    total_entry_fees = db.session.query(db.func.sum(Transaction.amount)) \
        .filter(Transaction.transaction_type == 'quiz_entry').scalar() or 0
    
    # Get recent transactions
    recent_transactions = Transaction.query.order_by(desc(Transaction.created_at)).limit(10).all()
    
    # Get pending withdrawals
    pending_withdrawals = Withdrawal.query.filter_by(status='pending').count()
    
    return render_template('admin.html', 
                          users_count=users_count,
                          matches_count=matches_count,
                          quizzes_count=quizzes_count,
                          questions_count=questions_count,
                          total_entry_fees=total_entry_fees,
                          recent_transactions=recent_transactions,
                          pending_withdrawals=pending_withdrawals)

@admin_bp.route('/matches')
@admin_required
def matches():
    matches = Match.query.order_by(desc(Match.match_date)).all()
    return render_template('admin_matches.html', matches=matches)

@admin_bp.route('/match/add', methods=['GET', 'POST'])
@admin_required
def add_match():
    if request.method == 'POST':
        title = request.form.get('title')
        team1 = request.form.get('team1')
        team2 = request.form.get('team2')
        match_date_str = request.form.get('match_date')
        is_live = request.form.get('is_live') == 'on'
        
        try:
            match_date = datetime.strptime(match_date_str, '%Y-%m-%dT%H:%M')
            
            match = Match(
                title=title,
                team1=team1,
                team2=team2,
                match_date=match_date,
                is_live=is_live,
                is_completed=False
            )
            
            db.session.add(match)
            db.session.commit()
            
            flash('Match added successfully', 'success')
            return redirect(url_for('admin.matches'))
        except Exception as e:
            logger.error(f"Error adding match: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('admin_add_match.html')

@admin_bp.route('/match/edit/<int:match_id>', methods=['GET', 'POST'])
@admin_required
def edit_match(match_id):
    match = Match.query.get_or_404(match_id)
    
    if request.method == 'POST':
        title = request.form.get('title')
        team1 = request.form.get('team1')
        team2 = request.form.get('team2')
        match_date_str = request.form.get('match_date')
        is_live = request.form.get('is_live') == 'on'
        is_completed = request.form.get('is_completed') == 'on'
        
        try:
            match_date = datetime.strptime(match_date_str, '%Y-%m-%dT%H:%M')
            
            match.title = title
            match.team1 = team1
            match.team2 = team2
            match.match_date = match_date
            match.is_live = is_live
            match.is_completed = is_completed
            
            db.session.commit()
            
            flash('Match updated successfully', 'success')
            return redirect(url_for('admin.matches'))
        except Exception as e:
            logger.error(f"Error updating match: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('admin_edit_match.html', match=match)

@admin_bp.route('/quizzes')
@admin_required
def quizzes():
    quizzes = Quiz.query.order_by(desc(Quiz.start_time)).all()
    return render_template('admin_quizzes.html', quizzes=quizzes)

@admin_bp.route('/quiz/add', methods=['GET', 'POST'])
@admin_required
def add_quiz():
    matches = Match.query.filter_by(is_completed=False).all()
    
    if request.method == 'POST':
        match_id = request.form.get('match_id')
        title = request.form.get('title')
        entry_fee = float(request.form.get('entry_fee', 10.0))
        start_time_str = request.form.get('start_time')
        end_time_str = request.form.get('end_time')
        
        try:
            match = Match.query.get(match_id)
            if not match:
                flash('Match not found', 'danger')
                return render_template('admin_add_quiz.html', matches=matches)
            
            start_time = datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M')
            end_time = datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M')
            
            # Result time is 2 hours after match ends
            result_time = end_time + timedelta(hours=2)
            
            # Determine status based on current time
            now = datetime.utcnow()
            if now < start_time:
                status = 'upcoming'
            elif now >= start_time and now <= end_time:
                status = 'active'
            else:
                status = 'completed'
            
            quiz = Quiz(
                match_id=match_id,
                title=title,
                entry_fee=entry_fee,
                start_time=start_time,
                end_time=end_time,
                result_time=result_time,
                status=status
            )
            
            db.session.add(quiz)
            db.session.commit()
            
            flash('Quiz added successfully', 'success')
            return redirect(url_for('admin.quizzes'))
        except Exception as e:
            logger.error(f"Error adding quiz: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('admin_add_quiz.html', matches=matches)

@admin_bp.route('/quiz/edit/<int:quiz_id>', methods=['GET', 'POST'])
@admin_required
def edit_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    matches = Match.query.all()
    
    if request.method == 'POST':
        match_id = request.form.get('match_id')
        title = request.form.get('title')
        entry_fee = float(request.form.get('entry_fee', 10.0))
        start_time_str = request.form.get('start_time')
        end_time_str = request.form.get('end_time')
        result_time_str = request.form.get('result_time')
        status = request.form.get('status')
        
        try:
            match = Match.query.get(match_id)
            if not match:
                flash('Match not found', 'danger')
                return render_template('admin_edit_quiz.html', quiz=quiz, matches=matches)
            
            start_time = datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M')
            end_time = datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M')
            result_time = datetime.strptime(result_time_str, '%Y-%m-%dT%H:%M')
            
            quiz.match_id = match_id
            quiz.title = title
            quiz.entry_fee = entry_fee
            quiz.start_time = start_time
            quiz.end_time = end_time
            quiz.result_time = result_time
            quiz.status = status
            
            db.session.commit()
            
            flash('Quiz updated successfully', 'success')
            return redirect(url_for('admin.quizzes'))
        except Exception as e:
            logger.error(f"Error updating quiz: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('admin_edit_quiz.html', quiz=quiz, matches=matches)

@admin_bp.route('/questions/<int:quiz_id>')
@admin_required
def questions(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    return render_template('admin_questions.html', quiz=quiz, questions=questions)

@admin_bp.route('/question/add/<int:quiz_id>', methods=['GET', 'POST'])
@admin_required
def add_question(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    
    if request.method == 'POST':
        question_text = request.form.get('question_text')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_option = request.form.get('correct_option')
        time_limit = int(request.form.get('time_limit', 30))
        
        try:
            question = Question(
                quiz_id=quiz_id,
                question_text=question_text,
                option_a=option_a,
                option_b=option_b,
                option_c=option_c,
                option_d=option_d,
                correct_option=correct_option,
                time_limit=time_limit
            )
            
            db.session.add(question)
            db.session.commit()
            
            flash('Question added successfully', 'success')
            return redirect(url_for('admin.questions', quiz_id=quiz_id))
        except Exception as e:
            logger.error(f"Error adding question: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('admin_add_question.html', quiz=quiz)

@admin_bp.route('/question/edit/<int:question_id>', methods=['GET', 'POST'])
@admin_required
def edit_question(question_id):
    question = Question.query.get_or_404(question_id)
    
    if request.method == 'POST':
        question_text = request.form.get('question_text')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_option = request.form.get('correct_option')
        time_limit = int(request.form.get('time_limit', 30))
        
        try:
            question.question_text = question_text
            question.option_a = option_a
            question.option_b = option_b
            question.option_c = option_c
            question.option_d = option_d
            question.correct_option = correct_option
            question.time_limit = time_limit
            
            db.session.commit()
            
            flash('Question updated successfully', 'success')
            return redirect(url_for('admin.questions', quiz_id=question.quiz_id))
        except Exception as e:
            logger.error(f"Error updating question: {str(e)}")
            db.session.rollback()
            flash('An error occurred. Please try again.', 'danger')
    
    return render_template('admin_edit_question.html', question=question)

@admin_bp.route('/users')
@admin_required
def users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

@admin_bp.route('/transactions')
@admin_required
def transactions():
    transactions = Transaction.query.order_by(desc(Transaction.created_at)).all()
    return render_template('admin_transactions.html', transactions=transactions)

@admin_bp.route('/withdrawals')
@admin_required
def withdrawals():
    withdrawals = Withdrawal.query.order_by(desc(Withdrawal.created_at)).all()
    return render_template('admin_withdrawals.html', withdrawals=withdrawals)

@admin_bp.route('/withdrawal/process/<int:withdrawal_id>', methods=['POST'])
@admin_required
def process_withdrawal(withdrawal_id):
    withdrawal = Withdrawal.query.get_or_404(withdrawal_id)
    
    if withdrawal.status != 'pending':
        flash('This withdrawal has already been processed', 'warning')
        return redirect(url_for('admin.withdrawals'))
    
    try:
        # In a real app, here you would integrate with payment gateway to process withdrawal
        transaction_id = f"TRANS-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        
        withdrawal.status = 'processed'
        withdrawal.transaction_id = transaction_id
        withdrawal.processed_at = datetime.utcnow()
        
        db.session.commit()
        
        flash('Withdrawal processed successfully', 'success')
    except Exception as e:
        logger.error(f"Error processing withdrawal: {str(e)}")
        db.session.rollback()
        flash('An error occurred. Please try again.', 'danger')
    
    return redirect(url_for('admin.withdrawals'))

@admin_bp.route('/stats')
@admin_required
def stats():
    # User statistics
    total_users = User.query.count()
    active_users = UserQuiz.query.distinct(UserQuiz.user_id).count()
    
    # Quiz statistics
    total_quizzes = Quiz.query.count()
    active_quizzes = Quiz.query.filter_by(status='active').count()
    completed_quizzes = Quiz.query.filter_by(status='completed').count()
    
    # Financial statistics
    total_entry_fees = db.session.query(db.func.sum(Transaction.amount)) \
        .filter(Transaction.transaction_type == 'quiz_entry').scalar() or 0
    total_rewards = db.session.query(db.func.sum(Transaction.amount)) \
        .filter(Transaction.transaction_type == 'reward').scalar() or 0
    admin_earnings = total_entry_fees * 0.5  # 50% of entry fees
    
    return render_template('admin_stats.html',
                          total_users=total_users,
                          active_users=active_users,
                          total_quizzes=total_quizzes,
                          active_quizzes=active_quizzes,
                          completed_quizzes=completed_quizzes,
                          total_entry_fees=total_entry_fees,
                          total_rewards=total_rewards,
                          admin_earnings=admin_earnings)
