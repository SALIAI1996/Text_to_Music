from flask import render_template
from auth import auth_bp
from quiz import quiz_bp
from admin import admin_bp
from payments import payments_bp

def register_routes(app):
    """Register all blueprint routes with the app."""
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(quiz_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(payments_bp)
    
    # Home page route
    @app.route('/')
    def index():
        return render_template('index.html')
    
    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('index.html', error="Page not found"), 404
    
    @app.errorhandler(500)
    def server_error(e):
        return render_template('index.html', error="Internal server error"), 500
