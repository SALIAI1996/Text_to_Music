from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    wallet_balance = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user_quizzes = db.relationship('UserQuiz', backref='user', lazy=True)
    transactions = db.relationship('Transaction', backref='user', lazy=True)
    withdrawals = db.relationship('Withdrawal', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def add_to_wallet(self, amount):
        self.wallet_balance += amount
        db.session.commit()
        
    def deduct_from_wallet(self, amount):
        if self.wallet_balance >= amount:
            self.wallet_balance -= amount
            db.session.commit()
            return True
        return False
    
    def __repr__(self):
        return f'<User {self.username}>'


class Match(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    team1 = db.Column(db.String(100), nullable=False)
    team2 = db.Column(db.String(100), nullable=False)
    match_date = db.Column(db.DateTime, nullable=False)
    is_live = db.Column(db.Boolean, default=False)
    is_completed = db.Column(db.Boolean, default=False)
    
    # Relationships
    quizzes = db.relationship('Quiz', backref='match', lazy=True)
    
    def __repr__(self):
        return f'<Match {self.title}>'


class Quiz(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    match_id = db.Column(db.Integer, db.ForeignKey('match.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    entry_fee = db.Column(db.Float, default=10.0)  # Default entry fee: 10 rupees
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    result_time = db.Column(db.DateTime, nullable=False)  # 2 hours after match ends
    total_participants = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='upcoming')  # upcoming, active, completed
    
    # Relationships
    questions = db.relationship('Question', backref='quiz', lazy=True)
    user_quizzes = db.relationship('UserQuiz', backref='quiz', lazy=True)
    
    @property
    def total_pool(self):
        return self.entry_fee * self.total_participants
    
    @property
    def reward_pool(self):
        return self.total_pool * 0.5  # 50% of the total collected amount
    
    def __repr__(self):
        return f'<Quiz {self.title}>'


class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    question_text = db.Column(db.String(500), nullable=False)
    option_a = db.Column(db.String(200), nullable=False)
    option_b = db.Column(db.String(200), nullable=False)
    option_c = db.Column(db.String(200), nullable=False)
    option_d = db.Column(db.String(200), nullable=False)
    correct_option = db.Column(db.String(1), nullable=False)  # a, b, c, or d
    time_limit = db.Column(db.Integer, default=30)  # Time limit in seconds
    
    def __repr__(self):
        return f'<Question {self.id}: {self.question_text[:30]}...>'


class UserQuiz(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey('quiz.id'), nullable=False)
    score = db.Column(db.Integer, default=0)
    time_taken = db.Column(db.Float, default=0)  # Total time taken in seconds
    completed = db.Column(db.Boolean, default=False)
    reward_amount = db.Column(db.Float, default=0.0)
    is_winner = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # User answers stored as JSON
    # Format: [{"question_id": 1, "answer": "a", "time_taken": 5.2, "is_correct": true}, ...]
    answers = db.Column(db.JSON, default=list)
    
    def __repr__(self):
        return f'<UserQuiz: User {self.user_id}, Quiz {self.quiz_id}, Score {self.score}>'


class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # deposit, quiz_entry, reward, withdrawal
    payment_id = db.Column(db.String(100), nullable=True)  # For external payment references
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Transaction {self.id}: {self.amount} Rs, {self.transaction_type}>'


class Withdrawal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    upi_id = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, processed, failed
    transaction_id = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<Withdrawal {self.id}: {self.amount} Rs, {self.status}>'
