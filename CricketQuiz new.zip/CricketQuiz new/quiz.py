import logging
from datetime import datetime, timedelta
from flask import Blueprint, request, render_template, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from sqlalchemy import desc, func
from app import db
from models import Match, Quiz, Question, UserQuiz, Transaction, User

# Configure logger
logger = logging.getLogger(__name__)

# Create quiz blueprint
quiz_bp = Blueprint('quiz', __name__, url_prefix='/quiz')

@quiz_bp.route('/dashboard')
@login_required
def dashboard():
    # Get upcoming matches
    upcoming_matches = Match.query.filter_by(is_completed=False).order_by(Match.match_date).all()
    
    # Get past matches
    past_matches = Match.query.filter_by(is_completed=True).order_by(desc(Match.match_date)).limit(5).all()
    
    # Get user's quiz history
    user_quizzes = UserQuiz.query.filter_by(user_id=current_user.id).order_by(desc(UserQuiz.created_at)).limit(5).all()
    
    return render_template('dashboard.html', 
                          upcoming_matches=upcoming_matches, 
                          past_matches=past_matches, 
                          user_quizzes=user_quizzes)

@quiz_bp.route('/matches')
@login_required
def matches():
    # Get all matches
    live_matches = Match.query.filter_by(is_live=True, is_completed=False).order_by(Match.match_date).all()
    upcoming_matches = Match.query.filter_by(is_live=False, is_completed=False).order_by(Match.match_date).all()
    past_matches = Match.query.filter_by(is_completed=True).order_by(desc(Match.match_date)).all()
    
    return render_template('matches.html', 
                          live_matches=live_matches,
                          upcoming_matches=upcoming_matches,
                          past_matches=past_matches)

@quiz_bp.route('/match/<int:match_id>')
@login_required
def match_details(match_id):
    match = Match.query.get_or_404(match_id)
    quizzes = Quiz.query.filter_by(match_id=match_id).all()
    
    # Check if user has already participated in any quiz for this match
    user_participations = {}
    for quiz in quizzes:
        user_quiz = UserQuiz.query.filter_by(user_id=current_user.id, quiz_id=quiz.id).first()
        user_participations[quiz.id] = user_quiz is not None
    
    return render_template('match_details.html', 
                          match=match, 
                          quizzes=quizzes, 
                          user_participations=user_participations)

@quiz_bp.route('/join/<int:quiz_id>', methods=['GET', 'POST'])
@login_required
def join_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    
    # Check if quiz is active
    if quiz.status != 'active':
        flash('This quiz is not currently active', 'danger')
        return redirect(url_for('quiz.match_details', match_id=quiz.match_id))
    
    # Check if user has already participated
    existing_participation = UserQuiz.query.filter_by(user_id=current_user.id, quiz_id=quiz_id).first()
    if existing_participation:
        flash('You have already participated in this quiz', 'info')
        return redirect(url_for('quiz.match_details', match_id=quiz.match_id))
    
    if request.method == 'POST':
        # Check if user has enough balance
        if current_user.wallet_balance < quiz.entry_fee:
            flash('Insufficient balance. Please add money to your wallet.', 'danger')
            return redirect(url_for('payments.wallet'))
        
        # Deduct entry fee
        if not current_user.deduct_from_wallet(quiz.entry_fee):
            flash('Payment failed. Please try again.', 'danger')
            return redirect(url_for('quiz.match_details', match_id=quiz.match_id))
        
        # Record transaction
        transaction = Transaction(
            user_id=current_user.id,
            amount=quiz.entry_fee,
            transaction_type='quiz_entry',
            status='completed'
        )
        db.session.add(transaction)
        
        # Create user quiz participation
        user_quiz = UserQuiz(
            user_id=current_user.id,
            quiz_id=quiz_id,
            score=0,
            time_taken=0,
            completed=False,
            answers=[]
        )
        db.session.add(user_quiz)
        
        # Update quiz participants count
        quiz.total_participants += 1
        
        db.session.commit()
        
        flash('Entry fee paid successfully. Good luck!', 'success')
        return redirect(url_for('quiz.start_quiz', quiz_id=quiz_id))
    
    return render_template('join_quiz.html', quiz=quiz)

@quiz_bp.route('/start/<int:quiz_id>')
@login_required
def start_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    
    # Check if user has paid
    user_quiz = UserQuiz.query.filter_by(user_id=current_user.id, quiz_id=quiz_id).first()
    if not user_quiz:
        flash('You need to pay the entry fee to participate in this quiz', 'danger')
        return redirect(url_for('quiz.join_quiz', quiz_id=quiz_id))
    
    # Check if user has already completed the quiz
    if user_quiz.completed:
        flash('You have already completed this quiz', 'info')
        return redirect(url_for('quiz.results', quiz_id=quiz_id))
    
    # Get all questions for this quiz
    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    
    return render_template('quiz.html', quiz=quiz, questions=questions)

@quiz_bp.route('/submit/<int:quiz_id>', methods=['POST'])
@login_required
def submit_quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    
    # Check if user has paid
    user_quiz = UserQuiz.query.filter_by(user_id=current_user.id, quiz_id=quiz_id).first()
    if not user_quiz:
        return jsonify({"error": "Not authorized to submit answers"}), 403
    
    # Check if already completed
    if user_quiz.completed:
        return jsonify({"error": "Quiz already submitted"}), 400
    
    # Process answers
    try:
        answers_data = request.json.get('answers', [])
        questions = Question.query.filter_by(quiz_id=quiz_id).all()
        question_map = {q.id: q for q in questions}
        
        total_score = 0
        total_time = 0
        processed_answers = []
        
        for answer in answers_data:
            question_id = answer.get('question_id')
            selected_option = answer.get('answer')
            time_taken = float(answer.get('time_taken', 0))
            
            question = question_map.get(int(question_id))
            if not question:
                continue
                
            is_correct = selected_option == question.correct_option
            points = 5 if is_correct else 0
            
            total_score += points
            total_time += time_taken
            
            processed_answers.append({
                "question_id": question_id,
                "answer": selected_option,
                "time_taken": time_taken,
                "is_correct": is_correct
            })
        
        # Update user quiz record
        user_quiz.score = total_score
        user_quiz.time_taken = total_time
        user_quiz.completed = True
        user_quiz.answers = processed_answers
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "score": total_score,
            "time_taken": total_time
        })
        
    except Exception as e:
        logger.error(f"Error submitting quiz: {str(e)}")
        return jsonify({"error": "Failed to process quiz submission"}), 500

@quiz_bp.route('/results/<int:quiz_id>')
@login_required
def results(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    user_quiz = UserQuiz.query.filter_by(user_id=current_user.id, quiz_id=quiz_id).first()
    
    if not user_quiz:
        flash('You have not participated in this quiz', 'info')
        return redirect(url_for('quiz.match_details', match_id=quiz.match_id))
    
    # Get all questions for this quiz
    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    question_map = {q.id: q for q in questions}
    
    # Check if results are ready
    results_ready = datetime.utcnow() >= quiz.result_time
    
    # Get top performers if results are ready
    top_performers = []
    if results_ready:
        # Calculate position based on score and time taken
        top_performers = UserQuiz.query.filter_by(quiz_id=quiz_id, completed=True) \
            .order_by(desc(UserQuiz.score), UserQuiz.time_taken) \
            .limit(10).all()
    
    return render_template('results.html', 
                          quiz=quiz, 
                          user_quiz=user_quiz,
                          questions=question_map,
                          results_ready=results_ready,
                          top_performers=top_performers)

@quiz_bp.route('/leaderboard/<int:quiz_id>')
@login_required
def leaderboard(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    
    # Calculate position based on score and time taken
    leaderboard_entries = UserQuiz.query.filter_by(quiz_id=quiz_id, completed=True) \
        .order_by(desc(UserQuiz.score), UserQuiz.time_taken) \
        .all()
    
    # Find current user's position
    user_position = None
    for index, entry in enumerate(leaderboard_entries):
        if entry.user_id == current_user.id:
            user_position = index + 1
            break
    
    return render_template('leaderboard.html', 
                          quiz=quiz, 
                          leaderboard=leaderboard_entries,
                          user_position=user_position)

@quiz_bp.route('/winners/<int:quiz_id>')
@login_required
def winners(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    
    # Check if results are ready
    if datetime.utcnow() < quiz.result_time:
        flash('Results are not yet available', 'info')
        return redirect(url_for('quiz.match_details', match_id=quiz.match_id))
    
    # Get all winners
    winners = UserQuiz.query.filter_by(quiz_id=quiz_id, is_winner=True) \
        .order_by(desc(UserQuiz.score), UserQuiz.time_taken) \
        .all()
    
    return render_template('winners.html', quiz=quiz, winners=winners)

# Scheduled task to process results (would be called by a scheduler in production)
@quiz_bp.route('/process_results/<int:quiz_id>', methods=['POST'])
def process_results(quiz_id):
    if request.headers.get('X-Admin-Key') != 'secret_admin_key':
        return jsonify({"error": "Unauthorized"}), 401
    
    quiz = Quiz.query.get_or_404(quiz_id)
    
    # Check if results should be processed
    if datetime.utcnow() < quiz.result_time:
        return jsonify({"error": "Results processing time not reached yet"}), 400
    
    try:
        # Calculate winners (top 20%)
        total_participants = quiz.total_participants
        winners_count = max(int(total_participants * 0.2), 1)  # At least 1 winner
        
        # Get top performers based on score and time
        top_performers = UserQuiz.query.filter_by(quiz_id=quiz_id, completed=True) \
            .order_by(desc(UserQuiz.score), UserQuiz.time_taken) \
            .limit(winners_count).all()
        
        # Calculate reward amount
        reward_pool = quiz.reward_pool
        min_reward = 10.0  # Minimum 10 rupees
        
        if len(top_performers) > 0:
            per_winner_reward = max(reward_pool / len(top_performers), min_reward)
            
            # Update winners and distribute rewards
            for user_quiz in top_performers:
                user_quiz.is_winner = True
                user_quiz.reward_amount = per_winner_reward
                
                # Add to user's wallet
                user = User.query.get(user_quiz.user_id)
                user.add_to_wallet(per_winner_reward)
                
                # Record transaction
                transaction = Transaction(
                    user_id=user_quiz.user_id,
                    amount=per_winner_reward,
                    transaction_type='reward',
                    status='completed'
                )
                db.session.add(transaction)
        
        # Update quiz status
        quiz.status = 'completed'
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "winners_count": len(top_performers),
            "reward_per_winner": per_winner_reward if len(top_performers) > 0 else 0
        })
        
    except Exception as e:
        logger.error(f"Error processing results: {str(e)}")
        db.session.rollback()
        return jsonify({"error": "Failed to process results"}), 500
